import{default as t}from"../components/error.svelte-4e0fc088.js";export{t as component};
