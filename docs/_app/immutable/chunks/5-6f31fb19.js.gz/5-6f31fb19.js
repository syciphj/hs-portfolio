import{_ as t}from"./_page-1bca56da.js";import{default as a}from"../components/pages/projects/_slug_/_page.svelte-47e99d27.js";const e=!0;export{a as component,e as server,t as shared};
