import{default as t}from"../components/error.svelte-f084450e.js";export{t as component};
