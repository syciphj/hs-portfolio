import{_ as r}from"./_page-0c4ddc22.js";import{default as t}from"../components/pages/_page.svelte-c13de3b1.js";export{t as component,r as shared};
