import{default as t}from"../components/pages/projects/_page.svelte-9032ae2b.js";const e=!0;export{t as component,e as server};
