import{default as t}from"../components/pages/_page.svelte-905d076c.js";export{t as component};
