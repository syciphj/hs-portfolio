import{_ as r}from"./_page-35798d3b.js";import{default as t}from"../components/pages/_page.svelte-bc186f7e.js";export{t as component,r as shared};
