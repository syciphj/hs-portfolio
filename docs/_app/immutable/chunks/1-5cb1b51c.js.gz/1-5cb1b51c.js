import{default as t}from"../components/error.svelte-c399c351.js";export{t as component};
