import{default as t}from"../components/error.svelte-d6bee138.js";export{t as component};
