import{default as t}from"../components/pages/projects/_page.svelte-11236926.js";const e=!0;export{t as component,e as server};
