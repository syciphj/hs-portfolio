import{_ as r}from"./_layout-1daba58d.js";import{default as t}from"../components/pages/_layout.svelte-7f75cb53.js";export{t as component,r as shared};
