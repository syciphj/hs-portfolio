import{default as t}from"../components/error.svelte-c6c0eb2c.js";export{t as component};
