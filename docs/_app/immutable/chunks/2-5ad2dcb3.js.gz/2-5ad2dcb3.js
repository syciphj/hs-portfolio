import{default as t}from"../components/pages/_page.svelte-9ac6ce38.js";export{t as component};
