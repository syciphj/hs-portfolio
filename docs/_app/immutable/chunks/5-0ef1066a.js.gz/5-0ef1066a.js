import{_ as t}from"./_page-09577de6.js";import{default as a}from"../components/pages/projects/_slug_/_page.svelte-be0e5937.js";const e=!0;export{a as component,e as server,t as shared};
