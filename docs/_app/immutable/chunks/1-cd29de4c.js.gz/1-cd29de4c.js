import{default as t}from"../components/error.svelte-05cb0127.js";export{t as component};
