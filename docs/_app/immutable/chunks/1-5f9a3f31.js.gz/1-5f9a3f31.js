import{default as t}from"../components/error.svelte-b0b69862.js";export{t as component};
