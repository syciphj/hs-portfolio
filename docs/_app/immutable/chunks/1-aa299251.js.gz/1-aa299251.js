import{default as t}from"../components/error.svelte-3575021c.js";export{t as component};
