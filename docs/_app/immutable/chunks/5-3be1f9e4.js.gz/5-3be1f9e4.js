import{_ as t}from"./_page-01a2b0c5.js";import{default as a}from"../components/pages/projects/_slug_/_page.svelte-90e160ca.js";const e=!0;export{a as component,e as server,t as shared};
