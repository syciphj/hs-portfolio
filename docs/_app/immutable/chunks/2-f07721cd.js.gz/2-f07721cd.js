import{default as t}from"../components/pages/_page.svelte-a1d12301.js";export{t as component};
