import{default as t}from"../components/error.svelte-245d707d.js";export{t as component};
