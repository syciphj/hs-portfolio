import{default as t}from"../components/pages/_page.svelte-045a3bf6.js";export{t as component};
