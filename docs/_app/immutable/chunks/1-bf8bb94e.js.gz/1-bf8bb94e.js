import{default as t}from"../components/error.svelte-d23ecc05.js";export{t as component};
