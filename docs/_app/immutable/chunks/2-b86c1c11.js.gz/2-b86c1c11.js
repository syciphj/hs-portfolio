import{default as t}from"../components/pages/_page.svelte-cc0363ed.js";export{t as component};
