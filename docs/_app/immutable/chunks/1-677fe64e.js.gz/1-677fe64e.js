import{default as t}from"../components/error.svelte-56cf4f04.js";export{t as component};
