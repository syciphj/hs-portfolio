import{default as t}from"../components/error.svelte-f4511288.js";export{t as component};
