import{default as t}from"../components/pages/contact/_page.svelte-ef326f07.js";export{t as component};
