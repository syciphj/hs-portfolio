import{default as t}from"../components/error.svelte-d9fb9590.js";export{t as component};
