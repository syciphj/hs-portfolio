import{default as t}from"../components/error.svelte-385dae2f.js";export{t as component};
