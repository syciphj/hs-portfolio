import{default as t}from"../components/pages/contact/_page.svelte-e13e191a.js";export{t as component};
