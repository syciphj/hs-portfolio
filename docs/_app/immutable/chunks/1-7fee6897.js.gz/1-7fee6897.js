import{default as t}from"../components/error.svelte-94ad81b4.js";export{t as component};
