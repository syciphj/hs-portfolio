import{default as t}from"../components/pages/contact/_page.svelte-2536daad.js";export{t as component};
