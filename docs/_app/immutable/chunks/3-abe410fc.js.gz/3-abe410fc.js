import{default as t}from"../components/pages/contact/_page.svelte-9dd6c883.js";export{t as component};
