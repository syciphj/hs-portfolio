import{_ as t}from"./_page-5749d016.js";import{default as a}from"../components/pages/projects/_slug_/_page.svelte-a0395bec.js";const e=!0;export{a as component,e as server,t as shared};
