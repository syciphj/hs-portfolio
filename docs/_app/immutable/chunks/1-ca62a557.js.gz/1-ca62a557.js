import{default as t}from"../components/error.svelte-d861a5cf.js";export{t as component};
