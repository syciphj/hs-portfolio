import{default as t}from"../components/pages/_page.svelte-6ec5923f.js";export{t as component};
