import{default as t}from"../components/error.svelte-7c1a1ad4.js";export{t as component};
