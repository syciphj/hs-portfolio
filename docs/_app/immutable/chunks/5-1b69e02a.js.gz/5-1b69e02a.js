import{_ as t}from"./_page-b428221b.js";import{default as a}from"../components/pages/projects/_slug_/_page.svelte-4e4f44e3.js";const e=!0;export{a as component,e as server,t as shared};
