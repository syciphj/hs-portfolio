import{default as t}from"../components/pages/projects/_page.svelte-ce028252.js";const e=!0;export{t as component,e as server};
