import{_ as r}from"./_page-9ef87fc3.js";import{default as t}from"../components/pages/contact/_page.svelte-ef326f07.js";export{t as component,r as shared};
