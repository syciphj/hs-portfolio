import{default as t}from"../components/error.svelte-05fe2a35.js";export{t as component};
