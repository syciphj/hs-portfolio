import{default as t}from"../components/error.svelte-fe45f505.js";export{t as component};
