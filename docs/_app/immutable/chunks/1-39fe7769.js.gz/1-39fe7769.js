import{default as t}from"../components/error.svelte-b92fc386.js";export{t as component};
