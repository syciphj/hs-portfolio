import{default as t}from"../components/pages/_page.svelte-0b626ff9.js";export{t as component};
