import{default as t}from"../components/pages/_page.svelte-68e07bdb.js";export{t as component};
