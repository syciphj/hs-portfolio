import{_ as r}from"./_layout-1daba58d.js";import{default as t}from"../components/pages/_layout.svelte-5bc6defe.js";export{t as component,r as shared};
