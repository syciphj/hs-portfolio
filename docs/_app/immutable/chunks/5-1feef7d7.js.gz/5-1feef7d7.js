import{_ as t}from"./_page-dfa35ae0.js";import{default as a}from"../components/pages/projects/_slug_/_page.svelte-4c7a0f0f.js";const e=!0;export{a as component,e as server,t as shared};
