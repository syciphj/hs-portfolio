import{_ as t}from"./_page-92a3e46a.js";import{default as a}from"../components/pages/projects/_slug_/_page.svelte-abf618e7.js";const e=!0;export{a as component,e as server,t as shared};
