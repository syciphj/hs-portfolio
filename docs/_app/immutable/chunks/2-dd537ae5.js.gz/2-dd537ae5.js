import{default as t}from"../components/pages/_page.svelte-0a32b4a3.js";export{t as component};
