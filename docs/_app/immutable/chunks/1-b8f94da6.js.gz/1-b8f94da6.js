import{default as t}from"../components/error.svelte-ec701204.js";export{t as component};
