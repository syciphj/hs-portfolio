import{_ as t}from"./_page-c064bb8e.js";import{default as a}from"../components/pages/projects/_slug_/_page.svelte-0cf4c5c7.js";const e=!0;export{a as component,e as server,t as shared};
