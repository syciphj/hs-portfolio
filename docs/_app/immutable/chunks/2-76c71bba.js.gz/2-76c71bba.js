import{default as t}from"../components/pages/_page.svelte-9b2be61b.js";export{t as component};
