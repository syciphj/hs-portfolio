import"../../../../chunks/preload-helper-b21cceae.js";import{l}from"../../../../chunks/_page-dfa35ae0.js";export{l as load};
