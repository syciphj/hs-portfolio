import{p}from"../../../chunks/_page-9ef87fc3.js";export{p as prerender};
